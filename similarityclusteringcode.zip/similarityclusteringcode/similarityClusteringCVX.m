% This program solves the following optimization problem using CVX 
% minimize trace(X) + (1/2) \lambda  ||A-X||_F^2
% subject to X is psd
% X is entrywise noneg
% X*ones(n,1) <= ones(n,1)
% Reference: R. K. Vinayak, B. Hassibi, "Similarity clustering in the presence of outliers: Exact
% recovery via convex program", ISIT 2016.

% Input: 
% A: Similarity matrix to be clustered
% lambda: regulization parameter needs tuning, typically 1/sqrt(n) or constant/sqrt(n) works very well
% Output:
% X: cleaner matrix which can them be clustered using spectral clustering
% or kmeans etc.
function X = similarityClusteringCVX(A, lambda, n)

cvx_begin sdp

variable X(n,n) symmetric;
 
minimize( trace(X) + 0.5.* lambda .*square_pos(norm(A-X,'fro')) )
 
subject to
 
 for i = 1  : n
     for j = i :  n
         X(i,j)>=0;
     end
 end
 X == semidefinite(n);
 sum(X, 2) <= ones(n, 1);
 
 cvx_end