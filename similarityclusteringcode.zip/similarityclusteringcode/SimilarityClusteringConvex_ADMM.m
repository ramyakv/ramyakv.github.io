% This program solves the following optimization problem using ADMM 
% minimize trace(X) + (1/2) \lambda  ||A-X||_F^2
% subject to X is psd
% X is entrywise noneg
% X*ones(n,1) <= ones(n,1)
% Reference: R. K. Vinayak, B. Hassibi, "Similarity clustering in the presence of outliers: Exact
% recovery via convex program", ISIT 2016.

% Input: 
% A: Similarity matrix
% n: number of nodes/items to be clustered ( A is n-by-n)
% lambda: regularization parameter, needs tuning, typically 1/sqrt(n) or constant/sqrt(n) 
% if there is some estimate of noise variance (in the entries of similarity
% matrix), say sigma^2 then, lamda slight smaller than 1/ (2*sigma*sqrt(n)
% is good. (See the reference).
% beta: beta > 0 parameter for ADMM. Need to tune this. Typically values
% like 0.04, 0.4... work for data with a few hundred nodes/items
% maxIter: Maximum number of iterations
% tol: tolerence for convergence

function X = SimilarityClusteringConvex_ADMM(A, n, lambda, beta, maxIter, tol)


I = eye(n);
c = ones(n,1);

X = zeros(n);
U = zeros(n);

Xold = X;
for iter = 1 : maxIter

    iter
    
    %% Minimize with respect to Y

    M = (beta*X + lambda*A - I - U)./(beta + lambda);
    [V, D] = eig(M);
    Dd = double(D>0);

    Y = V*Dd*V';
    
    %% Minimize with resepect to X

     LB = zeros(n, 1);
     UB = inf(n,1);
     z = minConf_TMP(@(z) objective(z, n , Y, U, beta), zeros(n,1) ,LB,UB);
     clear LB
     clear UB
   
   X = max(Y + (1/beta).*U - 0.5.*(z*c' + c*z'), 0);
     
   U = U - beta * ( X - Y ); 

   norm(X-Xold, 'fro')
   if (norm(X-Xold, 'fro') < tol)
       break;
   end
   Xold = X;
 
end